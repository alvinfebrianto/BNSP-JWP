<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <!-- Menyertakan Tailwind CSS dari CDN untuk styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Fungsi untuk mengurutkan tabel berdasarkan kolom yang dipilih
        function sortTable(n) {
            var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
            table = document.getElementById("data-table"); // Mengambil tabel berdasarkan ID
            switching = true; // Menandai bahwa tabel perlu disortir
            dir = "asc"; // Mengatur arah pengurutan awal ke ascending

            while (switching) {
                switching = false;
                rows = table.rows; // Mengambil semua baris tabel

                // Loop melalui semua baris tabel (kecuali header)
                for (i = 1; i < (rows.length - 1); i++) {
                    shouldSwitch = false;

                    x = rows[i].getElementsByTagName("TD")[n]; // Mendapatkan elemen TD di baris ke-i dan kolom n
                    y = rows[i + 1].getElementsByTagName("TD")[n]; // Mendapatkan elemen TD di baris ke-i+1 dan kolom n

                    // Jika kolom yang diurutkan adalah kolom usia (index 3), urutkan secara numerik
                    if (n === 3) {
                        if (dir === "asc") {
                            if (parseInt(x.innerHTML) > parseInt(y.innerHTML)) {
                                shouldSwitch = true;
                                break;
                            }
                        } else if (dir === "desc") {
                            if (parseInt(x.innerHTML) < parseInt(y.innerHTML)) {
                                shouldSwitch = true;
                                break;
                            }
                        }
                    } else {
                        // Urutkan secara alfabet untuk kolom lainnya
                        if (dir === "asc") {
                            if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                                shouldSwitch = true;
                                break;
                            }
                        } else if (dir === "desc") {
                            if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                                shouldSwitch = true;
                                break;
                            }
                        }
                    }
                }

                if (shouldSwitch) {
                    // Jika ada baris yang perlu dipindahkan, lakukan pemindahan
                    rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                    switching = true; // Menandai bahwa ada perubahan
                    switchcount++;
                } else {
                    // Jika tidak ada perubahan dan arah pengurutan adalah "asc", ubah arah menjadi "desc" dan jalankan loop lagi
                    if (switchcount === 0 && dir === "asc") {
                        dir = "desc";
                        switching = true;
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <!-- Header dari halaman -->
        <header class="mb-6">
            <h1 class="text-2xl font-bold text-center">Dashboard</h1>
        </header>
        <!-- Tabel data -->
        <table id="data-table" class="min-w-full bg-white rounded-lg shadow-md overflow-hidden">
            <thead>
                <tr class="bg-gray-200 text-left text-sm font-semibold text-gray-700">
                    <!-- Header tabel yang dapat diklik untuk mengurutkan data -->
                    <th class="p-4 cursor-pointer" onclick="sortTable(0)">Tanggal</th>
                    <th class="p-4 cursor-pointer" onclick="sortTable(1)">Nama</th>
                    <th class="p-4 cursor-pointer" onclick="sortTable(2)">Sekolah</th>
                    <th class="p-4 cursor-pointer" onclick="sortTable(3)">Usia</th>
                    <th class="p-4 cursor-pointer" onclick="sortTable(4)">Alamat</th>
                    <th class="p-4 cursor-pointer" onclick="sortTable(5)">Telepon</th>
                    <th class="p-4 cursor-pointer" onclick="sortTable(6)">Hasil</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <!-- Menampilkan data perhitungan yang diambil dari server -->
                @foreach ($calculations as $calculation)
                <tr class="border-t border-gray-200">
                    <td class="p-4">
                        <!-- Menampilkan tanggal pembuatan perhitungan -->
                        @if ($calculation->created_at)
                        {{ $calculation->created_at->format('Y-m-d H:i:s') }}
                        @else
                        N/A
                        @endif
                    </td>
                    <td class="p-4">{{ $calculation->name }}</td>
                    <td class="p-4">{{ $calculation->school }}</td>
                    <td class="p-4">{{ $calculation->age }}</td>
                    <td class="p-4">{{ $calculation->address }}</td>
                    <td class="p-4">{{ $calculation->phone }}</td>
                    <td class="p-4">{{ $calculation->result }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>