<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CalculationController;

Route::get('/', [CalculationController::class, 'index'])->name('calculate.index');
Route::post('/store', [CalculationController::class, 'store'])->name('calculate.store');
Route::get('/data', [CalculationController::class, 'show'])->name('data.index');
Route::get('/data/sort', [CalculationController::class, 'sort'])->name('data.sort');
Route::get('/stats', [CalculationController::class, 'stats'])->name('stats.index');