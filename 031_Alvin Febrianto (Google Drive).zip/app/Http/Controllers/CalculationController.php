<?php

namespace App\Http\Controllers;

use App\Models\Calculation; // Mengimpor model Calculation untuk mengelola data perhitungan
use Illuminate\Http\Request;

class CalculationController extends Controller
{
    // Method untuk menampilkan halaman form kalkulasi
    public function index()
    {
        return view('calculate'); // Mengarahkan ke tampilan 'calculate'
    }

    // Method untuk menyimpan data perhitungan yang dikirimkan dari form
    public function store(Request $request)
    {
        // Validasi data input dari form
        $request->validate([
            'name' => 'required|string', // Nama wajib diisi dan harus berupa string
            'school' => 'required|string', // Nama sekolah wajib diisi dan berupa string
            'age' => 'required|integer', // Usia wajib diisi dan berupa angka
            'address' => 'required|string', // Alamat wajib diisi dan berupa string
            'phone' => 'required|string', // Nomor telepon wajib diisi dan berupa string
            'shape' => 'required|string', // Jenis bangun wajib diisi dan berupa string
            'dimensions' => 'required|array' // Dimensi wajib diisi dan berupa array
        ]);

        // Menyimpan semua data yang diterima dari request ke variabel $data
        $data = $request->all();
        // Mengonversi array dimensi ke format JSON untuk penyimpanan
        $data['dimensions'] = json_encode($data['dimensions']);
        // Menghitung hasil berdasarkan jenis bangun dan dimensinya
        $data['result'] = $this->calculateResult($data['shape'], $data['dimensions']);

        // Menyimpan data perhitungan ke database menggunakan model Calculation
        Calculation::create($data);

        // Redirect kembali ke halaman daftar data setelah penyimpanan
        return redirect()->route('data.index');
    }

    // Method untuk menghitung hasil berdasarkan jenis bangun yang dipilih
    private function calculateResult($shape, $dimensionsJson)
    {
        // Mengonversi dimensi dari JSON ke array PHP
        $dimensions = json_decode($dimensionsJson, true);

        // Switch case untuk menghitung berdasarkan bentuk bangun yang dipilih
        switch ($shape) {
            case 'square':
                $side = $dimensions['side']; // Panjang sisi persegi
                $area = $side * $side; // Menghitung luas persegi
                return "Luas: $area";

            case 'triangle':
                $base = $dimensions['base']; // Panjang alas segitiga
                $height = $dimensions['height']; // Tinggi segitiga
                $area = 0.5 * $base * $height; // Menghitung luas segitiga
                return "Luas: $area";

            case 'circle':
                $radius = $dimensions['radius']; // Jari-jari lingkaran
                $area = pi() * $radius * $radius; // Menghitung luas lingkaran
                return "Luas: $area";

            case 'cube':
                $side = $dimensions['side']; // Panjang sisi kubus
                $volume = $side * $side * $side; // Menghitung volume kubus
                return "Volume: $volume";

            case 'pyramid':
                $baseArea = $dimensions['base_area']; // Luas alas limas
                $height = $dimensions['height']; // Tinggi limas
                $volume = (1/3) * $baseArea * $height; // Menghitung volume limas
                return "Volume: $volume";

            case 'cylinder':
                $radius = $dimensions['radius']; // Jari-jari tabung
                $height = $dimensions['height']; // Tinggi tabung
                $volume = pi() * $radius * $radius * $height; // Menghitung volume tabung
                return "Volume: $volume";

            default:
                return "Hasil tidak valid"; // Jika bentuk tidak dikenali
        }
    }

    // Method untuk menampilkan daftar data perhitungan
    public function show()
    {
        // Mengambil semua data perhitungan dari database
        $calculations = Calculation::all();
        // Mengarahkan ke tampilan 'data' dengan data perhitungan yang didapat
        return view('data', compact('calculations'));
    }

    // Method untuk mengurutkan data berdasarkan input
    public function sort(Request $request)
    {
        // Mendapatkan parameter pengurutan dari request, default 'created_at'
        $sortBy = $request->input('sort_by', 'created_at');
        // Mengambil data perhitungan yang diurutkan berdasarkan kolom yang dipilih
        $calculations = Calculation::orderBy($sortBy)->get();
        // Mengarahkan ke tampilan 'data' dengan data yang diurutkan
        return view('data', compact('calculations'));
    }

    // Method untuk menampilkan statistik data perhitungan
    public function stats()
    {
        // Mengambil semua data perhitungan dari database
        $calculations = Calculation::all();
        // Menghitung total jumlah perhitungan
        $totalCalculations = $calculations->count();

        // Mengelompokkan data perhitungan berdasarkan jenis bangun
        $shapeCounts = $calculations->groupBy('shape')->map->count();
        // Menghitung persentase masing-masing jenis bangun
        $shapePercentages = $shapeCounts->map(fn($count) => ($count / $totalCalculations) * 100);

        // Mengarahkan ke tampilan 'stats' dengan data total perhitungan dan persentase
        return view('stats', compact('totalCalculations', 'shapeCounts', 'shapePercentages'));
    }
}