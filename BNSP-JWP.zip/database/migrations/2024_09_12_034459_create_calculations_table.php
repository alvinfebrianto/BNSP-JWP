<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('calculations', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('school');
            $table->integer('age');
            $table->string('address');
            $table->string('phone');
            $table->string('shape');
            $table->json('dimensions'); // Menggunakan JSON untuk menyimpan dimensi
            $table->string('result'); // Kolom untuk hasil perhitungan, pastikan tipe data sesuai
            $table->timestamps(); // Menyimpan timestamp created_at dan updated_at
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('calculations');
    }
};